    <footer>
        <p>&copy; 2023 - <a href="https://wa.me/62895618748150" style="text-decoration: none;">Abdul Aziz Firdaus</a> - 312110262 - TI.21.A.3 - Universitas Pelita Bangsa - Bekasi Utara</p>
    </footer>
    </div>
    </body>

    </html>