<?php namespace CodeIgniter\Test\Mock;

use CodeIgniter\Database\Query;

class MockQuery extends Query
{

}
